// =============================================
// ThreadVerse - Actions (Business Logic)
// =============================================

/**
 * Vote on a post (up or down).
 * Toggles vote if already voted in same direction,
 * switches vote if voted in opposite direction.
 */
function vote(postId, dir) {
  if (!state.currentUser) { notify('Login to vote!'); return; }

  const post   = getPost(postId);
  const uid    = state.currentUser.id;
  const hasUp  = post.upvoted.includes(uid);
  const hasDown = post.downvoted.includes(uid);

  if (dir === 'up') {
    if (hasUp) {
      // Un-upvote
      post.upvoted = post.upvoted.filter(x => x !== uid);
      post.votes--;
    } else {
      // Remove downvote if present, then upvote
      if (hasDown) { post.downvoted = post.downvoted.filter(x => x !== uid); post.votes++; }
      post.upvoted.push(uid);
      post.votes++;
    }
  } else {
    if (hasDown) {
      // Un-downvote
      post.downvoted = post.downvoted.filter(x => x !== uid);
      post.votes++;
    } else {
      // Remove upvote if present, then downvote
      if (hasUp) { post.upvoted = post.upvoted.filter(x => x !== uid); post.votes--; }
      post.downvoted.push(uid);
      post.votes--;
    }
  }
  render();
}

/**
 * Vote on a comment (up or down).
 */
function voteComment(cid, dir) {
  if (!state.currentUser) { notify('Login to vote!'); return; }

  const c   = state.data.comments.find(x => x.id === cid);
  const uid = state.currentUser.id;

  if (dir === 'up') {
    c.upvoted.includes(uid) ? c.votes-- : c.votes++;
    c.upvoted.includes(uid)
      ? (c.upvoted = c.upvoted.filter(x => x !== uid))
      : c.upvoted.push(uid);
  } else {
    c.downvoted.includes(uid) ? c.votes++ : c.votes--;
    c.downvoted.includes(uid)
      ? (c.downvoted = c.downvoted.filter(x => x !== uid))
      : c.downvoted.push(uid);
  }
  render();
}

/**
 * Submit a new comment on the current post.
 */
function submitComment() {
  if (!state.currentUser)           { notify('Login to comment!');       return; }
  if (!state.newComment.trim())     { notify('Write something first!');  return; }

  const c = {
    id:        'cm' + Date.now(),
    postId:    state.postDetail,
    authorId:  state.currentUser.id,
    content:   state.newComment.trim(),
    votes:     1,
    upvoted:   [state.currentUser.id],
    downvoted: [],
    createdAt: Date.now()
  };

  state.data.comments.push(c);
  state.newComment = '';
  notify('Comment posted!');
  render();
}

/**
 * Submit a new post to a community.
 */
function submitPost() {
  if (!state.currentUser)                                          { notify('Login to post!');                   return; }
  if (!state.newPost.title.trim() || !state.newPost.communityId)  { notify('Fill in title and community!');     return; }

  const p = {
    id:          'p' + Date.now(),
    title:       state.newPost.title.trim(),
    content:     state.newPost.content.trim(),
    type:        state.newPost.type,
    communityId: state.newPost.communityId,
    authorId:    state.currentUser.id,
    votes:       1,
    upvoted:     [state.currentUser.id],
    downvoted:   [],
    comments:    [],
    createdAt:   Date.now()
  };

  state.data.posts.unshift(p);
  state.newPost        = { title: '', content: '', type: 'text', communityId: '', link: '' };
  state.showCreatePost = false;
  state.currentUser.karma++;
  notify('Post submitted!');
  render();
}

/**
 * Create a new community.
 */
function submitCommunity() {
  if (!state.currentUser)              { notify('Login first!');               return; }
  if (!state.newCommunity.name.trim()) { notify('Community needs a name!');    return; }

  const slug = state.newCommunity.name
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_]/g, '');

  if (state.data.communities.find(c => c.slug === slug)) { notify('Name taken!'); return; }

  const c = {
    id:         'c' + Date.now(),
    name:       state.newCommunity.name.trim(),
    slug,
    desc:       state.newCommunity.desc.trim() || 'A new community.',
    emoji:      state.newCommunity.emoji || '💬',
    color:      COLORS[Math.floor(Math.random() * COLORS.length)],
    members:    1,
    memberList: [state.currentUser.id]
  };

  state.data.communities.push(c);
  state.joinedCommunities.add(c.id);
  state.newCommunity          = { name: '', desc: '', emoji: '💻' };
  state.showCreateCommunity   = false;
  notify('Community created!');
  render();
}

/**
 * Log in with email + password.
 */
function login() {
  const u = state.data.users.find(
    x => x.email === state.loginForm.email && x.password === state.loginForm.password
  );
  if (!u) { notify('Invalid credentials!'); return; }

  state.currentUser  = u;
  state.page         = 'home';
  state.loginForm    = { email: '', password: '' };
  notify('Welcome back, ' + u.username + '!');
  render();
}

/**
 * Sign up with username, email, and password.
 */
function signup() {
  const { username, email, password } = state.signupForm;
  if (!username || !email || !password)               { notify('Fill all fields!');  return; }
  if (state.data.users.find(u => u.email === email))  { notify('Email taken!');      return; }

  const u = {
    id:           'u' + Date.now(),
    username,
    email,
    password,
    karma:        0,
    commentKarma: 0,
    joined:       'Today'
  };

  state.data.users.push(u);
  state.currentUser  = u;
  state.page         = 'home';
  state.signupForm   = { username: '', email: '', password: '' };
  notify('Welcome to ThreadVerse, ' + username + '!');
  render();
}

/**
 * Join or leave a community.
 */
function joinToggle(cid) {
  if (!state.currentUser) { notify('Login to join!'); return; }

  const c = getCommunity(cid);

  if (state.joinedCommunities.has(cid)) {
    state.joinedCommunities.delete(cid);
    c.members--;
    c.memberList = c.memberList.filter(x => x !== state.currentUser.id);
    notify('Left r/' + c.slug);
  } else {
    state.joinedCommunities.add(cid);
    c.members++;
    c.memberList.push(state.currentUser.id);
    notify('Joined r/' + c.slug + '!');
  }
  render();
}

/**
 * Navigate to a page. Extra properties are merged into state.
 */
function nav(page, extra) {
  state.page = page;
  if (extra) Object.assign(state, extra);
  window.scrollTo(0, 0);
  render();
}
