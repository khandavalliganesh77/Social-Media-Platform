// =============================================
// ThreadVerse - App Entry Point
// =============================================

// Form submit helpers (read DOM values then call action)
function submitLoginForm() {
  state.loginForm.email    = document.getElementById('login-email')?.value || '';
  state.loginForm.password = document.getElementById('login-pass')?.value  || '';
  login();
}

function submitSignupForm() {
  state.signupForm.username = document.getElementById('signup-user')?.value  || '';
  state.signupForm.email    = document.getElementById('signup-email')?.value || '';
  state.signupForm.password = document.getElementById('signup-pass')?.value  || '';
  signup();
}

// Expose all functions used by inline onclick handlers to the global scope
window.nav                = nav;
window.vote               = vote;
window.voteComment        = voteComment;
window.joinToggle         = joinToggle;
window.submitComment      = submitComment;
window.submitPost         = submitPost;
window.submitCommunity    = submitCommunity;
window.submitLoginForm    = submitLoginForm;
window.submitSignupForm   = submitSignupForm;
window.notify             = notify;
window.state              = state;

// Boot
render();
