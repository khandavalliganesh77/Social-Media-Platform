// =============================================
// ThreadVerse - Initial Seed Data
// =============================================

const COLORS = ['#ff5722', '#00bcd4', '#7c4dff', '#4caf50', '#f44336', '#ff9800', '#e91e63', '#2196f3'];
const EMOJIS = ['🔥', '🎮', '💻', '🎵', '🌍', '🏋️', '📸', '🎬', '📚', '🚀', '🎯', '⚽', '🍕', '🧠', '🎨'];

const initData = {
  users: [
    { id: 'u1', username: 'cosmic_dev',    email: 'cosmic@dev.com',      password: 'pass123', karma: 4821, commentKarma: 1204, joined: 'Jan 2024' },
    { id: 'u2', username: 'threadmaster',  email: 'thread@master.com',   password: 'pass123', karma: 2340, commentKarma: 890,  joined: 'Mar 2024' },
    { id: 'u3', username: 'syntax_witch',  email: 'sw@code.com',         password: 'pass123', karma: 7902, commentKarma: 3100, joined: 'Nov 2023' },
    { id: 'u4', username: 'pixel_phantom', email: 'px@phantom.com',      password: 'pass123', karma: 1102, commentKarma: 450,  joined: 'Jun 2024' },
  ],

  communities: [
    { id: 'c1', name: 'Programming',  slug: 'programming',  desc: 'Discuss code, projects, and tech.',       emoji: '💻', color: '#7c4dff', members: 48200,  memberList: ['u1', 'u2', 'u3'] },
    { id: 'c2', name: 'Gaming',       slug: 'gaming',       desc: 'All things video games.',                 emoji: '🎮', color: '#ff5722', members: 124500, memberList: ['u1', 'u2', 'u4'] },
    { id: 'c3', name: 'Science',      slug: 'science',      desc: 'Science news and discoveries.',           emoji: '🔬', color: '#00bcd4', members: 89300,  memberList: ['u2', 'u3'] },
    { id: 'c4', name: 'Music',        slug: 'music',        desc: 'Share music, discuss genres.',            emoji: '🎵', color: '#e91e63', members: 32100,  memberList: ['u3', 'u4'] },
    { id: 'c5', name: 'WorldNews',    slug: 'worldnews',    desc: 'Global news and current events.',         emoji: '🌍', color: '#4caf50', members: 201000, memberList: ['u1', 'u2', 'u3', 'u4'] },
    { id: 'c6', name: 'Photography',  slug: 'photography',  desc: 'Capture the world.',                      emoji: '📸', color: '#ff9800', members: 15700,  memberList: ['u4'] },
  ],

  posts: [
    {
      id: 'p1',
      title: 'I built a full-stack Reddit clone in 2 weeks using Next.js and PostgreSQL',
      content: 'Started this as a portfolio project and honestly learned more in 2 weeks than in months of tutorials. Key insights: Prisma makes relations a breeze, Next.js App Router is incredible for nested layouts, and auth with Clerk saved me days. Share your MVP war stories below!',
      type: 'text', communityId: 'c1', authorId: 'u1',
      votes: 1842, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 2
    },
    {
      id: 'p2',
      title: "What game has the best worldbuilding you've ever experienced?",
      content: "For me it's Elden Ring. The way lore is hidden in item descriptions and environment tells the story without ever spelling it out. Genuinely changed how I think about narrative design.",
      type: 'text', communityId: 'c2', authorId: 'u2',
      votes: 4203, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 5
    },
    {
      id: 'p3',
      title: 'Scientists discover a new type of photosynthesis in deep-sea organisms',
      content: 'Researchers at MIT have identified a previously unknown metabolic pathway in deep-sea bacteria that allows them to convert chemical energy in ways that defy current models. The implications for astrobiology are enormous.',
      type: 'link', communityId: 'c3', authorId: 'u3',
      votes: 892, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 8
    },
    {
      id: 'p4',
      title: 'Why Tailwind CSS is a productivity superpower (and why some people hate it)',
      content: "Hot take: the people who hate Tailwind have never shipped a product under real deadline pressure. Yes, the class names look verbose in isolation. But when you're iterating at speed, not context-switching to CSS files is a massive win.",
      type: 'text', communityId: 'c1', authorId: 'u3',
      votes: 567, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 12
    },
    {
      id: 'p5',
      title: "Album of the Decade: What's your pick and why?",
      content: 'No gatekeeping, no genre wars. Just your honest choice. Mine is To Pimp a Butterfly. Every listen reveals something new and it ages like fine wine.',
      type: 'text', communityId: 'c4', authorId: 'u4',
      votes: 2109, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 18
    },
    {
      id: 'p6',
      title: 'Breaking: Major climate agreement signed by 120 nations',
      content: 'Representatives from 120 countries signed a landmark agreement today committing to net-zero emissions by 2045, with binding carbon reduction targets reviewed every 3 years.',
      type: 'link', communityId: 'c5', authorId: 'u1',
      votes: 7821, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 1
    },
    {
      id: 'p7',
      title: 'My street photography setup: Sony A7C + 35mm f/1.8',
      content: 'After trying 6 different cameras, this combo hits the sweet spot of IQ, portability, and IBIS for handheld low-light shooting. Happy to answer questions about the setup.',
      type: 'image', communityId: 'c6', authorId: 'u4',
      votes: 442, upvoted: [], downvoted: [], comments: [], createdAt: Date.now() - 3600000 * 6
    },
  ],

  comments: [
    { id: 'cm1', postId: 'p1', authorId: 'u3', content: 'The schema design part is always the most underrated skill. Glad Prisma is getting more love. Did you use server actions or a separate Express backend?', votes: 234, upvoted: [], downvoted: [], createdAt: Date.now() - 3600000 },
    { id: 'cm2', postId: 'p1', authorId: 'u2', content: 'Bookmarking this. Currently on week 1 of my own clone and the voting logic is killing me.', votes: 98, upvoted: [], downvoted: [], createdAt: Date.now() - 1800000 },
    { id: 'cm3', postId: 'p2', authorId: 'u1', content: 'Morrowind for me. The world feels genuinely alien and dangerous. You can die from not reading a warning sign.', votes: 512, upvoted: [], downvoted: [], createdAt: Date.now() - 3600000 * 4 },
    { id: 'cm4', postId: 'p2', authorId: 'u4', content: 'Outer Wilds. The entire plot is told through archaeology. Nothing else comes close.', votes: 889, upvoted: [], downvoted: [], createdAt: Date.now() - 3600000 * 3 },
    { id: 'cm5', postId: 'p6', authorId: 'u3', content: "Historic moment. Let's see if the enforcement mechanisms are actually binding or performative.", votes: 1203, upvoted: [], downvoted: [], createdAt: Date.now() - 1800000 * 2 },
  ]
};
