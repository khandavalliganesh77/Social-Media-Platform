// =============================================
// ThreadVerse - Render Engine (View Layer)
// =============================================

// --- MAIN RENDER ---

function render() {
  const app = document.getElementById('app');

  // Auth screen has its own full-page layout
  if (state.page === 'auth') {
    app.innerHTML = renderAuth();
    return;
  }

  app.innerHTML = `
    ${renderNav()}
    <div class="app">
      <div class="content">
        <div class="main">
          ${renderMain()}
        </div>
        <div class="sidebar">
          ${renderSidebar()}
        </div>
      </div>
    </div>
    ${state.showCreatePost      ? renderCreatePostModal()      : ''}
    ${state.showCreateCommunity ? renderCreateCommunityModal() : ''}
    ${state.notification
      ? `<div style="position:fixed;bottom:24px;right:24px;z-index:999;background:#1a1a1f;border:1px solid var(--orange);border-radius:10px;padding:10px 18px;color:var(--text);font-size:13px;font-weight:500;animation:fadeIn 0.2s ease;">${state.notification}</div>`
      : ''}
  `;

  attachEvents();
}

// --- NAVIGATION BAR ---

function renderNav() {
  const u = state.currentUser;
  return `
    <nav>
      <div class="nav-left">
        <div class="logo" style="cursor:pointer" onclick="nav('home')">
          <div class="logo-dot"></div>ThreadVerse
        </div>
        <div class="search-bar">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.35-4.35"/>
          </svg>
          <input id="search-input" placeholder="Search posts..."
            value="${state.searchQuery}"
            oninput="state.searchQuery=this.value;render()">
        </div>
      </div>

      <div style="display:flex;align-items:center;gap:4px">
        <button class="btn btn-sm ${state.page === 'home'        ? 'btn-primary' : ''}" onclick="nav('home')">Home</button>
        <button class="btn btn-sm ${state.page === 'communities' ? 'btn-primary' : ''}" onclick="nav('communities')">Communities</button>
        ${u ? `
          <button class="btn btn-sm" onclick="state.showCreatePost=true;render()" style="border-color:var(--orange);color:var(--orange)">+ Post</button>
          <div class="avatar" onclick="nav('profile',{profileUser:state.currentUser})" title="${u.username}">${u.username[0].toUpperCase()}</div>
          <button class="btn btn-sm" onclick="state.currentUser=null;render()">Logout</button>
        ` : `
          <button class="btn btn-sm btn-primary" onclick="nav('auth')">Login</button>
        `}
      </div>
    </nav>
  `;
}

// --- MAIN CONTENT ROUTER ---

function renderMain() {
  if (state.searchQuery.trim()) return renderSearch();

  switch (state.page) {
    case 'home':        return renderHome();
    case 'communities': return renderCommunities();
    case 'post':        return renderPostDetail();
    case 'profile':     return renderProfile();
    case 'community':   return renderCommunityPage();
    default:            return renderHome();
  }
}

// --- HOME FEED ---

function renderHome() {
  const posts = getSortedPosts(state.data.posts);
  return `
    ${renderCreateBar()}
    <div class="sort-bar">
      <span style="font-size:12px;color:var(--text3);margin-right:4px">Sort:</span>
      <button class="sort-btn ${state.sort === 'popular' ? 'active' : ''}" onclick="state.sort='popular';render()">🔥 Popular</button>
      <button class="sort-btn ${state.sort === 'latest'  ? 'active' : ''}" onclick="state.sort='latest';render()">🕐 Latest</button>
    </div>
    ${posts.map(p => renderPostCard(p)).join('')}
  `;
}

// --- SEARCH RESULTS ---

function renderSearch() {
  const q           = state.searchQuery.toLowerCase();
  const posts       = state.data.posts.filter(p => p.title.toLowerCase().includes(q) || p.content.toLowerCase().includes(q));
  const communities = state.data.communities.filter(c => c.name.toLowerCase().includes(q) || c.slug.toLowerCase().includes(q));

  return `
    <div style="margin-bottom:12px;font-family:'Syne',sans-serif;font-weight:700;font-size:16px">Search: "${state.searchQuery}"</div>

    ${communities.length ? `
      <div class="feed-section-label">Communities (${communities.length})</div>
      ${communities.map(c => `
        <div class="community-card" onclick="nav('community',{communityDetail:'${c.id}'})">
          <div class="community-icon" style="background:${c.color}22">${c.emoji}</div>
          <div class="community-info">
            <div class="community-name">${c.name}</div>
            <div class="community-slug">r/${c.slug}</div>
            <div class="community-desc">${c.desc}</div>
          </div>
          <div>${formatNum(c.members)} members</div>
        </div>
      `).join('')}
    ` : ''}

    ${posts.length ? `
      <div class="feed-section-label" style="margin-top:12px">Posts (${posts.length})</div>
      ${posts.map(p => renderPostCard(p)).join('')}
    ` : ''}

    ${!posts.length && !communities.length ? `
      <div class="empty">
        <div class="empty-icon">🔍</div>
        <div class="empty-title">No results found</div>
        <p>Try a different search term</p>
      </div>
    ` : ''}
  `;
}

// --- COMMUNITIES LIST ---

function renderCommunities() {
  return `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="font-family:'Syne',sans-serif;font-weight:800;font-size:20px">Communities</h2>
      ${state.currentUser
        ? `<button class="btn btn-primary btn-sm" onclick="state.showCreateCommunity=true;render()">+ Create Community</button>`
        : ''}
    </div>
    <div class="communities-grid">
      ${state.data.communities.map(c => `
        <div class="community-card">
          <div class="community-icon" style="background:${c.color}22;font-size:20px">${c.emoji}</div>
          <div class="community-info" onclick="nav('community',{communityDetail:'${c.id}'})" style="cursor:pointer">
            <div class="community-name">${c.name}</div>
            <div class="community-slug">r/${c.slug}</div>
            <div class="community-desc">${c.desc}</div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0">
            <div class="community-stats">
              <div class="stat-num" style="color:var(--orange)">${formatNum(c.members)}</div>
              <div class="stat-label">members</div>
            </div>
            <button class="join-btn ${state.joinedCommunities.has(c.id) ? 'joined' : ''}" onclick="joinToggle('${c.id}')">
              ${state.joinedCommunities.has(c.id) ? '✓ Joined' : 'Join'}
            </button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// --- SINGLE COMMUNITY PAGE ---

function renderCommunityPage() {
  const c = getCommunity(state.communityDetail);
  if (!c) return `<div class="empty"><div class="empty-icon">❓</div><div class="empty-title">Community not found</div></div>`;

  const posts = getSortedPosts(state.data.posts.filter(p => p.communityId === c.id));

  return `
    <button class="back-btn" onclick="nav('home')">← Back to feed</button>
    <div class="community-header">
      <div class="community-header-icon" style="background:${c.color}22;font-size:28px">${c.emoji}</div>
      <div style="flex:1">
        <div class="community-header-name">${c.name}</div>
        <div class="community-header-slug">r/${c.slug}</div>
        <div class="community-header-desc">${c.desc}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
        <div style="text-align:center">
          <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:20px;color:var(--orange)">${formatNum(c.members)}</div>
          <div style="font-size:11px;color:var(--text3)">members</div>
        </div>
        <button class="join-btn ${state.joinedCommunities.has(c.id) ? 'joined' : ''}" onclick="joinToggle('${c.id}');render()">
          ${state.joinedCommunities.has(c.id) ? '✓ Joined' : 'Join'}
        </button>
      </div>
    </div>

    ${renderCreateBar(c.id)}

    <div class="sort-bar">
      <button class="sort-btn ${state.sort === 'popular' ? 'active' : ''}" onclick="state.sort='popular';render()">🔥 Popular</button>
      <button class="sort-btn ${state.sort === 'latest'  ? 'active' : ''}" onclick="state.sort='latest';render()">🕐 Latest</button>
    </div>

    ${posts.length
      ? posts.map(p => renderPostCard(p)).join('')
      : `<div class="empty"><div class="empty-icon">${c.emoji}</div><div class="empty-title">No posts yet</div><p>Be the first to post in r/${c.slug}!</p></div>`}
  `;
}

// --- POST DETAIL ---

function renderPostDetail() {
  const post = getPost(state.postDetail);
  if (!post) return `<div class="empty"><div class="empty-icon">🗑️</div><div class="empty-title">Post not found</div></div>`;

  const c        = getCommunity(post.communityId);
  const author   = getUser(post.authorId);
  const uid      = state.currentUser?.id;
  const hasUp    = post.upvoted.includes(uid  || '');
  const hasDown  = post.downvoted.includes(uid || '');
  const comments = getPostComments(post.id);

  return `
    <button class="back-btn" onclick="nav('home')">← Back</button>

    <div class="post-detail">
      <div class="vote-row" style="padding:10px 14px;border-bottom:1px solid var(--border)">
        <button class="vote-row-btn ${hasUp ? 'active' : ''}" onclick="vote('${post.id}','up')">▲ Upvote</button>
        <span style="font-family:'Syne',sans-serif;font-weight:700;font-size:15px">${formatNum(post.votes)}</span>
        <button class="vote-row-btn ${hasDown ? 'down-active' : ''}" onclick="vote('${post.id}','down')">▼</button>
        <span class="badge badge-orange" style="margin-left:auto;cursor:pointer" onclick="nav('community',{communityDetail:'${c.id}'})">${c.emoji} r/${c.slug}</span>
      </div>
      <div class="post-detail-inner">
        <div style="font-size:12px;color:var(--text3);margin-bottom:8px">
          Posted by <span style="color:var(--text2);font-weight:500">${author.username}</span> · ${timeAgo(post.createdAt)}
        </div>
        <div class="big-title">${post.title}</div>
        ${post.type === 'image' ? `<div class="post-image-placeholder" style="height:220px;margin-bottom:12px">📸 Image: ${post.title}</div>` : ''}
        ${post.type === 'link'  ? `<div style="background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;margin-bottom:12px;font-size:12px;color:var(--teal)">🔗 External Link</div>` : ''}
        <div class="post-content-full">${post.content}</div>
      </div>
    </div>

    <div class="comment-box">
      <h3>Comments (${comments.length})</h3>
      ${state.currentUser ? `
        <textarea class="comment-input" id="comment-input" placeholder="Share your thoughts..." rows="3">${state.newComment}</textarea>
        <div class="comment-submit">
          <button class="btn btn-primary" onclick="submitComment()">Post Comment</button>
        </div>
      ` : `
        <div style="color:var(--text3);font-size:13px;text-align:center;padding:1rem">
          <span style="cursor:pointer;color:var(--orange)" onclick="nav('auth')">Login</span> to comment
        </div>
      `}
    </div>

    ${comments.length
      ? comments.map(cm => {
          const ua   = getUser(cm.authorId);
          const cmUp = cm.upvoted.includes(uid || '');
          return `
            <div class="comment">
              <div class="comment-header">
                <div class="comment-avatar" style="background:var(--orange-bg);color:var(--orange)">${ua.username[0].toUpperCase()}</div>
                <span class="comment-author" style="cursor:pointer" onclick="nav('profile',{profileUser:${JSON.stringify(ua)}})">${ua.username}</span>
                <span class="comment-time">${timeAgo(cm.createdAt)}</span>
                <span style="margin-left:auto;font-size:12px;color:var(--text3)">▲ ${cm.votes}</span>
              </div>
              <div class="comment-content">${cm.content}</div>
              <div class="comment-vote">
                <button class="comment-vote-btn ${cmUp ? 'active' : ''}" style="${cmUp ? 'color:var(--orange)' : ''}" onclick="voteComment('${cm.id}','up')">▲ ${cm.votes}</button>
                <button class="comment-vote-btn" onclick="voteComment('${cm.id}','down')">▼</button>
              </div>
            </div>
          `;
        }).join('')
      : `<div class="empty" style="padding:1.5rem"><div class="empty-title">No comments yet</div><p>Start the conversation!</p></div>`}
  `;
}

// --- PROFILE PAGE ---

function renderProfile() {
  const u = state.profileUser || state.currentUser;
  if (!u) return `<div class="empty"><div class="empty-icon">👤</div><div class="empty-title">Not logged in</div></div>`;

  const userPosts    = getSortedPosts(getUserPosts(u.id));
  const userComments = getUserComments(u.id);
  const isOwn        = state.currentUser && state.currentUser.id === u.id;

  return `
    <button class="back-btn" onclick="nav('home')">← Back</button>
    <div class="profile-header">
      <div class="profile-big-avatar">${u.username[0].toUpperCase()}</div>
      <div>
        <div class="profile-name">
          ${u.username}
          ${isOwn ? `<span style="font-size:12px;background:var(--orange-bg);color:var(--orange);padding:2px 8px;border-radius:20px;font-family:DM Sans,sans-serif;font-weight:500">You</span>` : ''}
        </div>
        <div class="profile-handle" style="color:var(--text3)">Member since ${u.joined || '2024'}</div>
        <div class="profile-stats">
          <div class="profile-stat"><div class="profile-stat-num">${formatNum(u.karma)}</div><div class="profile-stat-label">Post karma</div></div>
          <div class="profile-stat"><div class="profile-stat-num">${formatNum(u.commentKarma)}</div><div class="profile-stat-label">Comment karma</div></div>
          <div class="profile-stat"><div class="profile-stat-num">${userPosts.length}</div><div class="profile-stat-label">Posts</div></div>
        </div>
      </div>
    </div>
    <div class="tabs" style="margin-bottom:1rem">
      <button class="tab active">Posts (${userPosts.length})</button>
      <button class="tab">Comments (${userComments.length})</button>
    </div>
    ${userPosts.length
      ? userPosts.map(p => renderPostCard(p)).join('')
      : `<div class="empty"><div class="empty-icon">📝</div><div class="empty-title">No posts yet</div></div>`}
  `;
}

// --- CREATE POST BAR ---

function renderCreateBar(prefillCommunity) {
  const u = state.currentUser;
  const openModal = prefillCommunity
    ? `state.newPost.communityId='${prefillCommunity}';state.showCreatePost=true;render();`
    : `state.showCreatePost=true;render();`;

  return `
    <div class="create-post-bar" onclick="${u ? openModal : "nav('auth')"}">
      <div class="avatar" style="width:34px;height:34px;font-size:13px;flex-shrink:0">${u ? u.username[0].toUpperCase() : '?'}</div>
      <div class="create-post-input">${u ? 'Create a post...' : 'Login to post...'}</div>
      <button class="btn btn-sm" style="flex-shrink:0;pointer-events:none">📝</button>
    </div>
  `;
}

// --- POST CARD ---

function renderPostCard(post) {
  const c      = getCommunity(post.communityId);
  const author = getUser(post.authorId);
  if (!c || !author) return '';

  const uid          = state.currentUser?.id || '';
  const hasUp        = post.upvoted.includes(uid);
  const hasDown      = post.downvoted.includes(uid);
  const commentCount = getPostComments(post.id).length;

  return `
    <div class="post-card">
      <div class="vote-col">
        <button class="vote-btn up ${hasUp   ? 'active' : ''}" onclick="event.stopPropagation();vote('${post.id}','up')">▲</button>
        <div class="vote-count">${formatNum(post.votes)}</div>
        <button class="vote-btn down ${hasDown ? 'active' : ''}" onclick="event.stopPropagation();vote('${post.id}','down')">▼</button>
      </div>
      <div class="post-body" onclick="nav('post',{postDetail:'${post.id}'})">
        <div class="post-meta">
          <span class="community-tag" onclick="event.stopPropagation();nav('community',{communityDetail:'${c.id}'})">${c.emoji} r/${c.slug}</span>
          <span class="meta-sep">·</span>
          <span class="meta-text">by ${author.username}</span>
          <span class="meta-sep">·</span>
          <span class="meta-text">${timeAgo(post.createdAt)}</span>
          ${post.type === 'link'  ? `<span class="badge badge-teal">link</span>` : ''}
          ${post.type === 'image' ? `<span class="badge badge-purple">image</span>` : ''}
        </div>
        <div class="post-title">${post.title}</div>
        ${post.type === 'text'  && post.content ? `<div class="post-preview">${post.content}</div>` : ''}
        ${post.type === 'image' ? `<div class="post-image-placeholder">📸 Image post</div>` : ''}
        <div class="post-actions">
          <button class="post-action-btn">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            ${commentCount} comments
          </button>
          <button class="post-action-btn" onclick="event.stopPropagation();notify('Link copied!')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
              <polyline points="16 6 12 2 8 6"/>
              <line x1="12" y1="2" x2="12" y2="15"/>
            </svg>
            Share
          </button>
        </div>
      </div>
    </div>
  `;
}

// --- SIDEBAR ---

function renderSidebar() {
  const topCommunities = [...state.data.communities].sort((a, b) => b.members - a.members).slice(0, 5);
  const u = state.currentUser;

  return `
    ${u ? `
      <div class="sidebar-card">
        <div class="user-card">
          <div class="big-avatar">${u.username[0].toUpperCase()}</div>
          <div class="username">${u.username}</div>
          <div style="font-size:12px;color:var(--text3)">Member since ${u.joined || '2024'}</div>
          <div class="karma-row">
            <div class="karma-item"><div class="karma-num">${formatNum(u.karma)}</div><div class="karma-label">karma</div></div>
            <div class="karma-item"><div class="karma-num">${getUserPosts(u.id).length}</div><div class="karma-label">posts</div></div>
            <div class="karma-item"><div class="karma-num">${getUserComments(u.id).length}</div><div class="karma-label">comments</div></div>
          </div>
          <button class="btn btn-sm" style="margin-top:10px;width:100%;text-align:center" onclick="nav('profile',{profileUser:state.currentUser})">View Profile</button>
        </div>
      </div>
    ` : `
      <div class="sidebar-card">
        <div style="text-align:center;padding:0.5rem 0">
          <div style="font-size:28px;margin-bottom:8px">🧵</div>
          <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:15px;margin-bottom:6px">Join ThreadVerse</div>
          <div style="font-size:12px;color:var(--text2);margin-bottom:12px">Create posts, join communities, and discuss what matters.</div>
          <button class="btn btn-primary" style="width:100%;padding:8px" onclick="nav('auth')">Get Started</button>
        </div>
      </div>
    `}

    <div class="sidebar-card">
      <h3>Top Communities</h3>
      ${topCommunities.map((c, i) => `
        <div class="sidebar-community" onclick="nav('community',{communityDetail:'${c.id}'})">
          <div style="font-size:12px;font-weight:700;color:var(--text3);width:16px">${i + 1}</div>
          <div class="sidebar-community-icon" style="background:${c.color}22">${c.emoji}</div>
          <div>
            <div class="sidebar-community-name">r/${c.slug}</div>
            <div style="font-size:11px;color:var(--text3)">${formatNum(c.members)} members</div>
          </div>
        </div>
      `).join('')}
      <button class="btn btn-sm" style="width:100%;margin-top:10px;text-align:center" onclick="nav('communities')">View All Communities →</button>
    </div>

    <div class="sidebar-card">
      <h3>About ThreadVerse</h3>
      <div style="font-size:13px;color:var(--text2);line-height:1.7">A community-driven platform where you can share, discuss, and discover what the internet is talking about today.</div>
      <div style="display:flex;gap:12px;margin-top:12px;flex-wrap:wrap">
        <div><div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--orange)">${formatNum(state.data.posts.length)}</div><div style="font-size:11px;color:var(--text3)">Posts</div></div>
        <div><div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--orange)">${formatNum(state.data.communities.length)}</div><div style="font-size:11px;color:var(--text3)">Communities</div></div>
        <div><div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--orange)">${formatNum(state.data.users.length)}</div><div style="font-size:11px;color:var(--text3)">Members</div></div>
      </div>
    </div>
  `;
}

// --- CREATE POST MODAL ---

function renderCreatePostModal() {
  return `
    <div class="modal-overlay" onclick="if(event.target.classList.contains('modal-overlay')){state.showCreatePost=false;render()}">
      <div class="modal">
        <div class="modal-header">
          <div class="modal-title">Create Post</div>
          <button class="modal-close" onclick="state.showCreatePost=false;render()">✕</button>
        </div>
        <div class="modal-body">
          <div>
            <div class="field-label">Community</div>
            <select class="field-input" id="post-community" onchange="state.newPost.communityId=this.value">
              <option value="">Select a community...</option>
              ${state.data.communities.map(c =>
                `<option value="${c.id}" ${state.newPost.communityId === c.id ? 'selected' : ''}>${c.emoji} r/${c.slug}</option>`
              ).join('')}
            </select>
          </div>
          <div>
            <div class="field-label">Post Type</div>
            <div class="type-tabs">
              <button class="type-tab ${state.newPost.type === 'text'  ? 'active' : ''}" onclick="state.newPost.type='text';render()">📝 Text</button>
              <button class="type-tab ${state.newPost.type === 'image' ? 'active' : ''}" onclick="state.newPost.type='image';render()">📸 Image</button>
              <button class="type-tab ${state.newPost.type === 'link'  ? 'active' : ''}" onclick="state.newPost.type='link';render()">🔗 Link</button>
            </div>
          </div>
          <div>
            <div class="field-label">Title</div>
            <input class="field-input" id="post-title" placeholder="An interesting title..."
              value="${state.newPost.title}" oninput="state.newPost.title=this.value">
          </div>
          ${state.newPost.type === 'text' ? `
            <div>
              <div class="field-label">Content</div>
              <textarea class="field-input" id="post-content" placeholder="Share your thoughts..." rows="4"
                oninput="state.newPost.content=this.value">${state.newPost.content}</textarea>
            </div>
          ` : ''}
          ${state.newPost.type === 'link' ? `
            <div>
              <div class="field-label">URL</div>
              <input class="field-input" id="post-link" placeholder="https://..."
                value="${state.newPost.link}" oninput="state.newPost.link=this.value">
            </div>
          ` : ''}
          ${state.newPost.type === 'image' ? `
            <div>
              <div style="background:var(--surface2);border:1px dashed var(--border2);border-radius:var(--radius);padding:2rem;text-align:center;color:var(--text3)">
                <div style="font-size:32px;margin-bottom:8px">📸</div>
                <div style="font-size:13px">Image upload (Cloudinary integration)</div>
                <div style="font-size:11px;margin-top:4px">MVP note: image URL stored as text</div>
              </div>
              <input class="field-input" id="post-link" placeholder="Or paste image URL..."
                value="${state.newPost.link}" oninput="state.newPost.link=this.value" style="margin-top:8px">
            </div>
          ` : ''}
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="state.showCreatePost=false;render()">Cancel</button>
          <button class="btn btn-primary" onclick="submitPost()">Submit Post</button>
        </div>
      </div>
    </div>
  `;
}

// --- CREATE COMMUNITY MODAL ---

function renderCreateCommunityModal() {
  return `
    <div class="modal-overlay" onclick="if(event.target.classList.contains('modal-overlay')){state.showCreateCommunity=false;render()}">
      <div class="modal">
        <div class="modal-header">
          <div class="modal-title">Create Community</div>
          <button class="modal-close" onclick="state.showCreateCommunity=false;render()">✕</button>
        </div>
        <div class="modal-body">
          <div>
            <div class="field-label">Name</div>
            <input class="field-input" placeholder="CoolCommunity"
              value="${state.newCommunity.name}" oninput="state.newCommunity.name=this.value">
          </div>
          <div>
            <div class="field-label">Description</div>
            <input class="field-input" placeholder="What is this community about?"
              value="${state.newCommunity.desc}" oninput="state.newCommunity.desc=this.value">
          </div>
          <div>
            <div class="field-label">Emoji Icon</div>
            <div style="display:flex;flex-wrap:wrap;gap:8px">
              ${EMOJIS.map(e => `
                <button onclick="state.newCommunity.emoji='${e}';render()"
                  style="font-size:20px;padding:6px;border:1px solid ${state.newCommunity.emoji === e ? 'var(--orange)' : 'var(--border)'};border-radius:8px;background:${state.newCommunity.emoji === e ? 'var(--orange-bg)' : 'transparent'}">${e}</button>
              `).join('')}
            </div>
          </div>
          ${state.newCommunity.name ? `
            <div style="background:var(--surface2);border-radius:var(--radius);padding:10px 12px;font-size:13px;color:var(--text2)">
              Preview: <span style="color:var(--orange);font-weight:600">
                ${state.newCommunity.emoji} r/${state.newCommunity.name.toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9_]/g,'')}
              </span>
            </div>
          ` : ''}
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="state.showCreateCommunity=false;render()">Cancel</button>
          <button class="btn btn-primary" onclick="submitCommunity()">Create Community</button>
        </div>
      </div>
    </div>
  `;
}

// --- AUTH SCREEN ---

function renderAuth() {
  const isLogin = state.authTab === 'login';
  return `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-logo">
          <div class="logo"><div class="logo-dot"></div>ThreadVerse</div>
          <div class="auth-subtitle">The front page of your internet</div>
        </div>
        <div class="auth-tabs">
          <button class="auth-tab ${isLogin ? 'active' : ''}"  onclick="state.authTab='login';render()">Login</button>
          <button class="auth-tab ${!isLogin ? 'active' : ''}" onclick="state.authTab='signup';render()">Sign Up</button>
        </div>

        ${isLogin ? `
          <div class="auth-field">
            <div class="field-label">Email</div>
            <input class="field-input" type="email" id="login-email" placeholder="your@email.com" value="${state.loginForm.email}">
          </div>
          <div class="auth-field">
            <div class="field-label">Password</div>
            <input class="field-input" type="password" id="login-pass" placeholder="••••••••" value="${state.loginForm.password}">
          </div>
          <button class="auth-btn" onclick="submitLoginForm()">Login to ThreadVerse</button>
          <div style="text-align:center;margin-top:14px;font-size:12px;color:var(--text3)">
            Demo accounts: cosmic@dev.com / pass123
          </div>
        ` : `
          <div class="auth-field">
            <div class="field-label">Username</div>
            <input class="field-input" id="signup-user" placeholder="cool_username" value="${state.signupForm.username}">
          </div>
          <div class="auth-field">
            <div class="field-label">Email</div>
            <input class="field-input" type="email" id="signup-email" placeholder="your@email.com" value="${state.signupForm.email}">
          </div>
          <div class="auth-field">
            <div class="field-label">Password</div>
            <input class="field-input" type="password" id="signup-pass" placeholder="Choose a strong password" value="${state.signupForm.password}">
          </div>
          <button class="auth-btn" onclick="submitSignupForm()">Create Account</button>
        `}

        <button class="btn" style="width:100%;margin-top:10px;text-align:center" onclick="nav('home')">← Browse without account</button>
      </div>
    </div>
  `;
}

// --- EVENT ATTACHMENT ---

function attachEvents() {
  // Sync comment textarea to state
  const ci = document.getElementById('comment-input');
  if (ci) ci.addEventListener('input', e => state.newComment = e.target.value);
}
