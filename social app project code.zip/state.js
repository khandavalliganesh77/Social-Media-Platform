// =============================================
// ThreadVerse - Application State
// =============================================

let state = {
  // Routing
  page: 'home',            // home | communities | post | profile | community | auth

  // Auth
  currentUser: null,
  authTab: 'login',        // login | signup
  loginForm:  { email: '', password: '' },
  signupForm: { username: '', email: '', password: '' },

  // Data (deep copy of initData so mutations don't affect seed)
  data: JSON.parse(JSON.stringify(initData)),

  // Navigation context
  postDetail:      null,   // id of post being viewed
  communityDetail: null,   // id of community being viewed
  profileUser:     null,   // user object for profile page

  // Sorting
  sort: 'popular',         // popular | latest

  // Modals
  showCreatePost:      false,
  showCreateCommunity: false,

  // New content forms
  newPost:      { title: '', content: '', type: 'text', communityId: '', link: '' },
  newCommunity: { name: '', desc: '', emoji: '💻' },
  newComment:   '',

  // Joined communities (pre-populated for demo)
  joinedCommunities: new Set(['c1', 'c2', 'c5']),

  // Search
  searchQuery: '',

  // Toast notification
  notification: null,
};
