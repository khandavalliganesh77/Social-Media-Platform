// =============================================
// ThreadVerse - Utility / Helper Functions
// =============================================

/**
 * Returns a human-readable time-ago string from a timestamp.
 * e.g. "just now", "5m ago", "2h ago", "3d ago"
 */
function timeAgo(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60)    return 'just now';
  if (d < 3600)  return Math.floor(d / 60)    + 'm ago';
  if (d < 86400) return Math.floor(d / 3600)  + 'h ago';
  return           Math.floor(d / 86400) + 'd ago';
}

/**
 * Formats a number into a compact string.
 * e.g. 1500 → "1.5k"
 */
function formatNum(n) {
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n;
}

// --- Data Lookup Helpers ---

function getCommunity(id)      { return state.data.communities.find(c => c.id === id); }
function getUser(id)           { return state.data.users.find(u => u.id === id); }
function getPost(id)           { return state.data.posts.find(p => p.id === id); }
function getUserPosts(uid)     { return state.data.posts.filter(p => p.authorId === uid); }
function getUserComments(uid)  { return state.data.comments.filter(c => c.authorId === uid); }

/**
 * Returns comments for a post, sorted by votes (highest first).
 */
function getPostComments(pid) {
  return state.data.comments
    .filter(c => c.postId === pid)
    .sort((a, b) => b.votes - a.votes);
}

/**
 * Returns a sorted copy of the given posts array.
 * 'popular' sorts by votes desc; 'latest' sorts by createdAt desc.
 */
function getSortedPosts(posts) {
  if (state.sort === 'latest') return [...posts].sort((a, b) => b.createdAt - a.createdAt);
  return [...posts].sort((a, b) => b.votes - a.votes);
}

/**
 * Shows a temporary toast notification at the bottom-right of the screen.
 */
function notify(msg) {
  state.notification = msg;
  render();
  setTimeout(() => { state.notification = null; render(); }, 2500);
}
