# ThreadVerse – VS Code Project

A Reddit-style social platform built with vanilla HTML, CSS, and JavaScript.  
No build tools, no dependencies — open one file and it runs.

---

## 📁 Project Structure

```
threadverse-vscode/
│
├── index.html          ← Entry point (open this in your browser)
│
├── css/
│   ├── base.css        ← CSS variables, resets, animations
│   ├── components.css  ← Buttons, modals, forms, badges, auth card
│   └── layout.css      ← Navbar, post cards, sidebar, communities
│
├── js/
│   ├── data.js         ← Seed data (users, communities, posts, comments)
│   ├── state.js        ← Global app state object
│   ├── utils.js        ← Pure helpers (timeAgo, formatNum, nav, notify…)
│   ├── actions.js      ← All user actions / state mutations
│   ├── render.js       ← HTML template functions
│   └── main.js         ← Bootstrap, exposes globals, calls render()
│
└── README.md
```

---

## 🚀 How to Run

### Option A – Double-click (quickest)
Just double-click `index.html`. It opens directly in your browser.

### Option B – VS Code Live Server (recommended)
1. Install the **Live Server** extension in VS Code  
   *(search "Live Server" by Ritwick Dey in the Extensions panel)*
2. Right-click `index.html` → **Open with Live Server**
3. The app opens at `http://127.0.0.1:5500`

---

## 🔑 Demo Accounts

| Email                | Password  | Username       |
|----------------------|-----------|----------------|
| cosmic@dev.com       | pass123   | cosmic_dev     |
| thread@master.com    | pass123   | threadmaster   |
| sw@code.com          | pass123   | syntax_witch   |
| px@phantom.com       | pass123   | pixel_phantom  |

Or click **Sign Up** to create a new account.

---

## ✅ Features

- 🔐 Login / Sign Up / Logout
- 🏘️ Browse & create communities
- 📝 Create posts (Text / Image / Link)
- ▲▼ Upvote & Downvote posts and comments
- 💬 Add and vote on comments
- 🔀 Sort posts by Popular or Latest
- 🔍 Search posts and communities
- 👤 User profiles with karma stats
- 📱 Responsive sidebar hides on mobile

---

## 🛠️ How to Extend

| Want to add…                | Where to look                    |
|-----------------------------|----------------------------------|
| A new page                  | `js/render.js` → add `renderXxx()`, add case in `renderMain()` |
| A new action (e.g. bookmark)| `js/actions.js`                  |
| New seed data               | `js/data.js` → `INIT_DATA`       |
| Style tweaks                | `css/components.css` or `layout.css` |
| Connect to a real backend   | Replace `actions.js` functions with `fetch()` calls |

---

## 🔮 Next Steps (full-stack upgrade)

1. Add a **Node.js + Express** backend  
2. Use **PostgreSQL + Prisma** for the database  
3. Swap `actions.js` logic for real API calls  
4. Add **JWT auth** (or Clerk for speed)  
5. Deploy frontend on **Vercel**, backend on **Render**

See the project PDF for the full 2-week plan and tech stack details.
