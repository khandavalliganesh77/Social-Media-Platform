// js/actions.js
// ─────────────────────────────────────────────────────────────
//  All state mutations triggered by user interaction
// ─────────────────────────────────────────────────────────────

/* ── Voting ────────────────────────────────────────────────── */
function vote(postId, dir) {
  if (!state.currentUser) { notify('Login to vote!'); return; }

  const post = getPost(postId);
  const uid  = state.currentUser.id;
  const hasUp   = post.upvoted.includes(uid);
  const hasDown = post.downvoted.includes(uid);

  if (dir === 'up') {
    if (hasUp) {
      post.upvoted = post.upvoted.filter(x => x !== uid);
      post.votes--;
    } else {
      if (hasDown) { post.downvoted = post.downvoted.filter(x => x !== uid); post.votes++; }
      post.upvoted.push(uid);
      post.votes++;
    }
  } else {
    if (hasDown) {
      post.downvoted = post.downvoted.filter(x => x !== uid);
      post.votes++;
    } else {
      if (hasUp) { post.upvoted = post.upvoted.filter(x => x !== uid); post.votes--; }
      post.downvoted.push(uid);
      post.votes--;
    }
  }
  render();
}

function voteComment(cid, dir) {
  if (!state.currentUser) { notify('Login to vote!'); return; }

  const c   = state.data.comments.find(x => x.id === cid);
  const uid = state.currentUser.id;

  if (dir === 'up') {
    if (c.upvoted.includes(uid)) { c.votes--; c.upvoted = c.upvoted.filter(x => x !== uid); }
    else                         { c.votes++; c.upvoted.push(uid); }
  } else {
    if (c.downvoted.includes(uid)) { c.votes++; c.downvoted = c.downvoted.filter(x => x !== uid); }
    else                           { c.votes--; c.downvoted.push(uid); }
  }
  render();
}

/* ── Comments ──────────────────────────────────────────────── */
function submitComment() {
  if (!state.currentUser)      { notify('Login to comment!');     return; }
  if (!state.newComment.trim()){ notify('Write something first!'); return; }

  const c = {
    id:        'cm' + Date.now(),
    postId:    state.postDetail,
    authorId:  state.currentUser.id,
    content:   state.newComment.trim(),
    votes:     1,
    upvoted:   [state.currentUser.id],
    downvoted: [],
    createdAt: Date.now(),
  };
  state.data.comments.push(c);
  state.newComment = '';
  notify('Comment posted!');
  render();
}

/* ── Posts ─────────────────────────────────────────────────── */
function submitPost() {
  if (!state.currentUser)                           { notify('Login to post!');                  return; }
  if (!state.newPost.title.trim() || !state.newPost.communityId) { notify('Fill in title and community!'); return; }

  const p = {
    id:          'p'  + Date.now(),
    title:       state.newPost.title.trim(),
    content:     state.newPost.content.trim(),
    type:        state.newPost.type,
    communityId: state.newPost.communityId,
    authorId:    state.currentUser.id,
    votes:       1,
    upvoted:     [state.currentUser.id],
    downvoted:   [],
    createdAt:   Date.now(),
  };

  state.data.posts.unshift(p);
  state.newPost             = { title: '', content: '', type: 'text', communityId: '', link: '' };
  state.showCreatePost      = false;
  state.currentUser.karma++;
  notify('Post submitted!');
  render();
}

/* ── Communities ───────────────────────────────────────────── */
function submitCommunity() {
  if (!state.currentUser)           { notify('Login first!');             return; }
  if (!state.newCommunity.name.trim()) { notify('Community needs a name!'); return; }

  const slug = state.newCommunity.name
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_]/g, '');

  if (state.data.communities.find(c => c.slug === slug)) {
    notify('Name taken!'); return;
  }

  const c = {
    id:         'c'  + Date.now(),
    name:       state.newCommunity.name.trim(),
    slug,
    desc:       state.newCommunity.desc.trim() || 'A new community.',
    emoji:      state.newCommunity.emoji || '💬',
    color:      COLORS[Math.floor(Math.random() * COLORS.length)],
    members:    1,
    memberList: [state.currentUser.id],
  };

  state.data.communities.push(c);
  state.joinedCommunities.add(c.id);
  state.newCommunity         = { name: '', desc: '', emoji: '💻' };
  state.showCreateCommunity  = false;
  notify('Community created!');
  render();
}

/* ── Auth ──────────────────────────────────────────────────── */
function login() {
  const u = state.data.users.find(
    x => x.email === state.loginForm.email && x.password === state.loginForm.password
  );
  if (!u) { notify('Invalid credentials!'); return; }

  state.currentUser  = u;
  state.page         = 'home';
  state.loginForm    = { email: '', password: '' };
  notify('Welcome back, ' + u.username + '!');
  render();
}

function signup() {
  const { username, email, password } = state.signupForm;
  if (!username || !email || !password) { notify('Fill all fields!'); return; }
  if (state.data.users.find(u => u.email === email)) { notify('Email taken!'); return; }

  const u = {
    id:           'u' + Date.now(),
    username, email, password,
    karma: 0, commentKarma: 0, joined: 'Today',
  };
  state.data.users.push(u);
  state.currentUser = u;
  state.page        = 'home';
  state.signupForm  = { username: '', email: '', password: '' };
  notify('Welcome to ThreadVerse, ' + username + '!');
  render();
}

/* ── Join / Leave community ────────────────────────────────── */
function joinToggle(cid) {
  if (!state.currentUser) { notify('Login to join!'); return; }

  const c = getCommunity(cid);
  if (state.joinedCommunities.has(cid)) {
    state.joinedCommunities.delete(cid);
    c.members--;
    c.memberList = c.memberList.filter(x => x !== state.currentUser.id);
    notify('Left r/' + c.slug);
  } else {
    state.joinedCommunities.add(cid);
    c.members++;
    c.memberList.push(state.currentUser.id);
    notify('Joined r/' + c.slug + '!');
  }
  render();
}

/* ── Form helpers (called from inline onclicks) ────────────── */
function submitLoginForm() {
  state.loginForm.email    = document.getElementById('login-email')?.value || '';
  state.loginForm.password = document.getElementById('login-pass')?.value  || '';
  login();
}

function submitSignupForm() {
  state.signupForm.username = document.getElementById('signup-user')?.value  || '';
  state.signupForm.email    = document.getElementById('signup-email')?.value || '';
  state.signupForm.password = document.getElementById('signup-pass')?.value  || '';
  signup();
}
