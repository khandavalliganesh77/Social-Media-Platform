// js/main.js
// ─────────────────────────────────────────────────────────────
//  Entry point – expose globals and kick off first render
// ─────────────────────────────────────────────────────────────

// Expose every function that can be called from inline onclick=""
window.nav                  = nav;
window.vote                 = vote;
window.voteComment          = voteComment;
window.joinToggle           = joinToggle;
window.submitComment        = submitComment;
window.submitPost           = submitPost;
window.submitCommunity      = submitCommunity;
window.submitLoginForm      = submitLoginForm;
window.submitSignupForm     = submitSignupForm;
window.notify               = notify;
window.state                = state;       // useful for browser DevTools debugging

// Boot the app
render();
