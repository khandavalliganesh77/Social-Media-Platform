// js/state.js
// ─────────────────────────────────────────────────────────────
//  Single global state object – all UI reads from here
// ─────────────────────────────────────────────────────────────

const state = {
  // ── Routing ────────────────────────────────────────────────
  page:            'home',   // 'home' | 'communities' | 'post' | 'profile' | 'community' | 'auth'
  postDetail:      null,     // post id when page === 'post'
  communityDetail: null,     // community id when page === 'community'
  profileUser:     null,     // user object when page === 'profile'

  // ── Auth ───────────────────────────────────────────────────
  currentUser:     null,
  loginForm:       { email: '', password: '' },
  signupForm:      { username: '', email: '', password: '' },
  authTab:         'login',  // 'login' | 'signup'

  // ── Data (deep-clone of INIT_DATA so mutations are safe) ───
  data:            JSON.parse(JSON.stringify(INIT_DATA)),

  // ── UI toggles ─────────────────────────────────────────────
  showCreatePost:       false,
  showCreateCommunity:  false,
  sort:                 'popular',  // 'popular' | 'latest'
  searchQuery:          '',
  notification:         null,

  // ── Form state ─────────────────────────────────────────────
  newPost:      { title: '', content: '', type: 'text', communityId: '', link: '' },
  newCommunity: { name: '', desc: '', emoji: '💻' },
  newComment:   '',

  // ── Joined communities (Set of community ids) ─────────────
  joinedCommunities: new Set(['c1', 'c2', 'c5']),
};
