// js/utils.js
// ─────────────────────────────────────────────────────────────
//  Pure utility helpers – no side effects
// ─────────────────────────────────────────────────────────────

/** Format a timestamp as a relative "X ago" string */
function timeAgo(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60)    return 'just now';
  if (d < 3600)  return Math.floor(d / 60)    + 'm ago';
  if (d < 86400) return Math.floor(d / 3600)  + 'h ago';
  return          Math.floor(d / 86400)        + 'd ago';
}

/** Abbreviate large numbers: 1200 → "1.2k" */
function formatNum(n) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000)     return (n / 1_000).toFixed(1)     + 'k';
  return String(n);
}

// ── Data lookups ───────────────────────────────────────────────
const getCommunity  = (id) => state.data.communities.find(c => c.id === id);
const getUser       = (id) => state.data.users.find(u => u.id === id);
const getPost       = (id) => state.data.posts.find(p => p.id === id);
const getUserPosts  = (uid) => state.data.posts.filter(p => p.authorId === uid);
const getUserComments = (uid) => state.data.comments.filter(c => c.authorId === uid);
const getPostComments = (pid) =>
  state.data.comments.filter(c => c.postId === pid).sort((a, b) => b.votes - a.votes);

/** Return posts sorted by the current state.sort value */
function getSortedPosts(posts) {
  if (state.sort === 'latest') return [...posts].sort((a, b) => b.createdAt - a.createdAt);
  return [...posts].sort((a, b) => b.votes - a.votes);
}

/** Show a brief toast notification */
function notify(msg) {
  state.notification = msg;
  render();
  setTimeout(() => { state.notification = null; render(); }, 2500);
}

/** Navigate to a page, optionally merging extra state, then re-render */
function nav(page, extra) {
  state.page = page;
  if (extra) Object.assign(state, extra);
  window.scrollTo(0, 0);
  render();
}
